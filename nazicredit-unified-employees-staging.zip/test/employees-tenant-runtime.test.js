const test = require("node:test");
const assert = require("node:assert/strict");
const { __test: employeeService } = require("../server");

function runtimePool(fixtures) {
  const calls = [];
  return {
    calls,
    async query(sql, params = []) {
      calls.push({ sql, params });
      const tenant = params[params.length - 1];
      if (/FROM customer_credit_users\s+WHERE enterprise_id\s*=\s*\?/s.test(sql)) {
        return [fixtures.users.filter((row) => row.enterpriseId === params[0])];
      }
      if (/FROM customer_credit_time_entries entry INNER JOIN customer_credit_users/s.test(sql)) {
        return [fixtures.entries.filter((row) => row.enterpriseId === params[0])];
      }
      if (/FROM customer_credit_registered_devices/.test(sql)) return [[]];
      if (/FROM customer_credit_audit_log/.test(sql)) return [[]];
      if (/SELECT id FROM customer_credit_users WHERE id=\? AND enterprise_id=\?/.test(sql)) {
        const found = fixtures.users.find((row) => row.id === params[0] && row.enterpriseId === params[1]);
        return [found ? [{ id: found.id }] : []];
      }
      if (/UPDATE customer_credit_time_entries SET clock_in=/.test(sql)) {
        const found = fixtures.entries.find((row) => row.id === params[4] && row.enterpriseId === params[5] && !row.paidAt);
        return [{ affectedRows: found ? 1 : 0 }];
      }
      if (/INSERT INTO customer_credit_audit_log/.test(sql)) return [{ affectedRows: 1 }];
      throw new Error(`Unexpected query: ${sql}`);
    },
  };
}

const fixtures = {
  users: [
    { id: "a-user", enterpriseId: "business-a", username: "alice", displayName: "Alice", role: "employee", status: "active", mustChangePassword: 0 },
    { id: "b-user", enterpriseId: "business-b", username: "bob", displayName: "Bob", role: "employee", status: "active", mustChangePassword: 0 },
  ],
  entries: [
    { id: "a-entry", enterpriseId: "business-a", employeeId: "a-user", employeeName: "Alice", clockIn: "2026-08-19T09:00:00", clockOut: "2026-08-19T17:00:00", paidAt: null },
    { id: "b-entry", enterpriseId: "business-b", employeeId: "b-user", employeeName: "Bob", clockIn: "2026-08-19T09:00:00", clockOut: "2026-08-19T17:00:00", paidAt: null },
  ],
};

test("Business A runtime reads never return Business B employees or time entries", async () => {
  const pool = runtimePool(fixtures);
  employeeService.setPool(pool);
  const users = await employeeService.listEnterpriseUsers("business-a");
  const admin = await employeeService.getTimeClockAdminData({ enterpriseId: "business-a" });
  assert.deepEqual(users.map((row) => row.id), ["a-user"]);
  assert.deepEqual(admin.entries.map((row) => row.id), ["a-entry"]);
  assert.ok(pool.calls.every((call) => !call.params.includes("business-b")));
});

test("Business A cannot adjust Business B employee or time entry", async () => {
  const pool = runtimePool(fixtures);
  employeeService.setPool(pool);
  await assert.rejects(
    employeeService.saveTimeEntryAdjustment(
      { enterpriseId: "business-a", userId: "a-owner", username: "owner-a" },
      { id: "b-entry", employeeId: "b-user", clockIn: "2026-08-19T09:00:00Z", clockOut: "2026-08-19T17:00:00Z", reason: "test" },
    ),
    (error) => error.statusCode === 404 && error.message === "Employee not found",
  );
  assert.equal(pool.calls.filter((call) => /UPDATE customer_credit_time_entries/.test(call.sql)).length, 0);
});

test("authorized time adjustment carries Business A scope into the mutation", async () => {
  const pool = runtimePool(fixtures);
  employeeService.setPool(pool);
  await employeeService.saveTimeEntryAdjustment(
    { enterpriseId: "business-a", userId: "a-owner", username: "owner-a" },
    { id: "a-entry", employeeId: "a-user", clockIn: "2026-08-19T09:30:00Z", clockOut: "2026-08-19T17:30:00Z", reason: "approved correction" },
  );
  const mutation = pool.calls.find((call) => /UPDATE customer_credit_time_entries/.test(call.sql));
  assert.ok(mutation);
  assert.equal(mutation.params[5], "business-a");
  assert.equal(mutation.params[4], "a-entry");
});
