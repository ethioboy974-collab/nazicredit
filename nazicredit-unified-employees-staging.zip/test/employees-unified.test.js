const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const server = fs.readFileSync(path.join(root, "server.js"), "utf8");
const html = fs.readFileSync(path.join(root, "employees.html"), "utf8");
const client = fs.readFileSync(path.join(root, "employees.js"), "utf8");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");

test("navigation exposes one Employees destination and legacy pages redirect", () => {
  assert.equal((index.match(/>Employees<\/a>/g) || []).length, 1);
  assert.doesNotMatch(index, />Time Clock<\/a>|>Employee Management<\/a>/);
  assert.match(server, /const employeesRedirects = new Set/);
  for (const route of ["/employee-management", "/employee-management.html", "/time-clock", "/time-clock.html", "/time-clock-admin", "/time-clock-admin.html"]) {
    assert.ok(server.includes(`"${route}"`), `missing legacy redirect for ${route}`);
  }
  assert.match(server, /redirect\(response, `\/employees\.html\$\{requestUrl\.search\}`\)/);
});

test("unified page retains account, clock, time-entry, device, payroll, and audit actions", () => {
  for (const marker of ["employeeForm", "clockInButton", "clockOutButton", "ownEntries", "entryForm", "currentRows", "historyRows", "deviceForm", "activityList", "loginList", "auditRows"]) {
    assert.match(html, new RegExp(`id="${marker}"`));
  }
  assert.match(client, /api\("\/users"\)/);
  assert.match(client, /`\/users\/\$\{encodeURIComponent\(id\)\}`/);
  assert.match(client, /api\(`\/time-clock\/\$\{action\}`/);
  assert.match(client, /\/time-clock\/admin\/entry/);
  assert.match(client, /\/time-clock\/admin\/payroll/);
});

test("employees see only self-service data while owner-only data stays server protected", () => {
  assert.match(client, /if \(state\.me\.role !== "owner"\) return/);
  assert.match(server, /GET" && requestUrl\.pathname === "\/api\/time-clock\/admin"[\s\S]*?requireEnterpriseOwner\(session\)/);
  assert.match(server, /requestUrl\.pathname === "\/api\/users"[\s\S]*?requireEnterpriseOwner\(session\)/);
  assert.match(server, /FROM customer_credit_time_entries[\s\S]*?WHERE enterprise_id = \? AND user_id = \?/);
});

test("employee and time-entry reads and mutations remain authenticated-tenant scoped", () => {
  assert.match(server, /FROM customer_credit_users\s+WHERE enterprise_id = \?/);
  assert.match(server, /WHERE id = \? AND enterprise_id = \?/);
  assert.match(server, /WHERE entry\.enterprise_id=\?/);
  assert.match(server, /WHERE id=\? AND enterprise_id=\? AND paid_at IS NULL/);
  assert.match(server, /WHERE enterprise_id=\? AND id IN \(\$\{placeholders\}\)/);
  assert.match(server, /SELECT id FROM customer_credit_users WHERE id=\? AND enterprise_id=\?/);
  assert.doesNotMatch(client, /business_id|businessId|enterprise_id|enterpriseId/);
});

test("historical paid entries are rendered read-only and no migration deletes time data", () => {
  assert.match(html, /Paid and historical records are read-only and retained/);
  assert.match(client, /const history = state\.admin\.entries\.filter\(\(entry\) => entry\.paidAt\)/);
  assert.match(server, /ORDER BY entry\.clock_in DESC LIMIT 2000/);
  assert.doesNotMatch(server, /DELETE FROM customer_credit_time_entries/);
});
