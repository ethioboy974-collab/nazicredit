const state = { me: null, users: [], clock: null, admin: null };
const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
const dt = (value) => value ? new Date(value).toLocaleString() : "—";

async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, { credentials: "same-origin", headers: { "Content-Type": "application/json" }, ...options });
  if (response.status === 401) { location.href = "/login"; throw new Error("Login required"); }
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) throw new Error(result.error || "Request failed");
  return result;
}

function message(value) {
  const target = $("#message");
  target.textContent = value;
  target.hidden = false;
  clearTimeout(message.timer);
  message.timer = setTimeout(() => { target.hidden = true; }, 4500);
}

async function load() {
  const [me, clock] = await Promise.all([api("/me"), api("/time-clock")]);
  state.me = me.user;
  state.clock = clock;
  $("#currentUser").textContent = `Signed in as ${state.me.username} (${state.me.role})`;
  renderMyClock();
  if (state.me.role !== "owner") return;
  $("#ownerWorkspace").hidden = false;
  const [users, admin, activity, logins] = await Promise.all([
    api("/users"), api("/time-clock/admin"), api("/activity"), api("/login-history"),
  ]);
  state.users = users.users;
  state.admin = admin;
  renderOwner(activity.activity, logins.history);
}

function renderMyClock() {
  const active = state.clock.activeShift;
  $("#clockStatus").textContent = active ? `Clocked in since ${dt(active.clockIn)}` : "You are currently clocked out.";
  $("#clockInButton").disabled = Boolean(active) || !state.clock.deviceApproved;
  $("#clockOutButton").disabled = !active || !state.clock.deviceApproved;
  const note = state.clock.deviceApproved ? "" : '<p class="helper">Clock actions are disabled until an owner registers this device below.</p>';
  $("#ownEntries").innerHTML = note + (state.clock.ownEntries.length
    ? state.clock.ownEntries.slice(0, 20).map((entry) => timeEntry(entry)).join("")
    : "<p>No time entries yet.</p>");
}

function renderOwner(activity, logins) {
  const entriesByEmployee = new Map();
  state.admin.entries.forEach((entry) => {
    if (!entriesByEmployee.has(entry.employeeId)) entriesByEmployee.set(entry.employeeId, []);
    entriesByEmployee.get(entry.employeeId).push(entry);
  });
  $("#employeeList").innerHTML = state.users.map((user) => {
    const entries = entriesByEmployee.get(user.id) || [];
    const open = entries.find((entry) => !entry.clockOut);
    const nextStatus = user.status === "active" ? "inactive" : "active";
    const profile = user.role === "employee" ? ` · ID ${esc(user.employeeNumber || "Not set")} · ${esc(user.phone || "No phone")}` : "";
    const controls = user.id === state.me.id ? "<span>Your account</span>" : `<div class="card-actions"><button class="button secondary" data-edit-user="${esc(user.id)}">Edit</button><button class="button secondary" data-reset-user="${esc(user.id)}">Reset password</button>${user.role === "employee" ? `<button class="button ${nextStatus === "inactive" ? "danger" : "secondary"}" data-user-status="${nextStatus}" data-user-id="${esc(user.id)}">${nextStatus === "active" ? "Activate" : "Deactivate"}</button>` : ""}</div>`;
    return `<article class="employee-card"><div class="employee-summary"><div><strong>${esc(user.displayName)} <span class="badge">${esc(user.role)}</span> <span class="badge">${esc(user.status)}</span>${open ? ' <span class="badge open">Clocked in</span>' : ""}</strong><span>Username: ${esc(user.username)}${profile}${user.mustChangePassword ? " · Password change required" : ""}</span></div>${controls}</div><details class="employee-details"><summary>${entries.length} time ${entries.length === 1 ? "entry" : "entries"}</summary><div class="employee-time-list">${entries.length ? entries.map((entry) => timeEntry(entry, true)).join("") : "<p>No time entries.</p>"}</div></details></article>`;
  }).join("");
  $("#entryForm").elements.employeeId.innerHTML = state.users.filter((user) => user.role === "employee" && user.status === "active").map((user) => `<option value="${esc(user.id)}">${esc(user.displayName)} (${esc(user.employeeNumber || user.username)})</option>`).join("");
  renderPayroll();
  $("#deviceList").innerHTML = state.admin.devices.map((device) => `<div class="card"><div><strong>${esc(device.deviceName)}</strong> <span class="${device.status === "inactive" ? "inactive" : ""}">${esc(device.status)}</span><br><small>Last used: ${device.lastUsedAt ? dt(device.lastUsedAt) : "Never"}</small></div>${device.status === "active" ? `<button data-disable-device="${esc(device.id)}" class="secondary">Deactivate</button>` : ""}</div>`).join("") || "No registered tablets.";
  renderAudit($("#activityList"), activity.map((item) => ({ title: item.summary, detail: `${item.username} · ${item.action}`, date: item.createdAt })));
  renderAudit($("#loginList"), logins.map((item) => ({ title: `${item.username} — ${item.outcome}`, detail: item.ipAddress || "Unknown device address", date: item.createdAt })));
  $("#auditRows").innerHTML = state.admin.audit.map((item) => `<tr><td>${dt(item.createdAt)}</td><td>${esc(item.username)}</td><td>${esc(item.action)}</td><td>${esc(item.summary)}</td></tr>`).join("") || empty(4, "No time-clock activity.");
}

function timeEntry(entry, owner = false) {
  return `<div class="time-entry ${entry.clockOut ? "" : "open"}"><span><strong>In</strong> ${dt(entry.clockIn)}</span><span><strong>Out</strong> ${entry.clockOut ? dt(entry.clockOut) : "Open"}</span><span>${hours(entry)} hours${entry.paidAt ? ` · Paid ${dt(entry.paidAt)}` : ""}${owner && !entry.paidAt ? ` · <button data-edit-entry="${esc(entry.id)}" class="secondary">Adjust</button>` : ""}</span></div>`;
}

function renderPayroll() {
  const current = state.admin.entries.filter((entry) => !entry.paidAt);
  const history = state.admin.entries.filter((entry) => entry.paidAt);
  $("#currentRows").innerHTML = current.map((entry) => `<tr><td><input type="checkbox" data-pay-id="${esc(entry.id)}" ${entry.clockOut ? "" : "disabled"}></td><td>${esc(entry.employeeName)}</td><td>${dt(entry.clockIn)}</td><td>${entry.clockOut ? dt(entry.clockOut) : "Open"}</td><td>${hours(entry)}</td><td>${period(entry.clockIn)}</td><td><button data-edit-entry="${esc(entry.id)}" class="secondary">Adjust</button></td></tr>`).join("") || empty(7, "No unpaid time records.");
  $("#historyRows").innerHTML = history.map((entry) => `<tr><td>${esc(entry.employeeName)}</td><td>${dt(entry.clockIn)}</td><td>${dt(entry.clockOut)}</td><td>${hours(entry)}</td><td>${dt(entry.paidAt)}</td></tr>`).join("") || empty(5, "No payroll history.");
  const totals = new Map();
  current.forEach((entry) => totals.set(entry.employeeName, (totals.get(entry.employeeName) || 0) + Number(hours(entry) === "—" ? 0 : hours(entry))));
  $("#totals").innerHTML = [...totals].map(([name, total]) => `<span>${esc(name)}: ${total.toFixed(2)} hours</span>`).join("");
}

function editUser(id, resetPassword = false) {
  const user = state.users.find((item) => item.id === id);
  if (!user) return;
  const form = $("#employeeForm");
  ["id", "displayName", "username", "role", "status", "employeeNumber", "phone"].forEach((name) => { form.elements[name].value = user[name] || ""; });
  form.elements.password.value = "";
  $("#formTitle").textContent = resetPassword ? `Reset password — ${user.displayName}` : `Edit — ${user.displayName}`;
  toggleEmployeeFields();
  (resetPassword ? form.elements.password : form.elements.displayName).focus();
}

function clearEmployeeForm() { $("#employeeForm").reset(); $("#employeeForm").elements.id.value = ""; $("#formTitle").textContent = "Add employee"; toggleEmployeeFields(); }
function toggleEmployeeFields() { const employee = $("#employeeForm").elements.role.value === "employee"; document.querySelectorAll("[data-employee-field]").forEach((field) => { field.hidden = !employee; }); }
async function saveUser(event) { event.preventDefault(); const form = event.currentTarget; const body = Object.fromEntries(new FormData(form)); const id = body.id; delete body.id; if (!id && !body.password) throw new Error("Temporary password is required for a new account."); await api(id ? `/users/${encodeURIComponent(id)}` : "/users", { method: id ? "PATCH" : "POST", body: JSON.stringify(body) }); clearEmployeeForm(); await load(); message(id ? "Account updated." : "Account created."); }
async function changeStatus(id, status) { await api(`/users/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify({ status }) }); await load(); message(`Employee ${status}.`); }
async function clock(action) { await api(`/time-clock/${action}`, { method: "POST", body: "{}" }); await load(); message(action === "in" ? "Clocked in." : "Clocked out."); }
async function saveEntry(event) { event.preventDefault(); const form = event.currentTarget; await api("/time-clock/admin/entry", { method: "POST", body: JSON.stringify(Object.fromEntries(new FormData(form))) }); form.reset(); await load(); message("Time entry saved."); }
async function markPaid() { const ids = [...document.querySelectorAll("[data-pay-id]:checked")].map((input) => input.dataset.payId); if (!ids.length) throw new Error("Select completed time records first."); await api("/time-clock/admin/payroll", { method: "POST", body: JSON.stringify({ ids }) }); await load(); message("Selected records moved to payroll history."); }
async function registerDevice(event) { event.preventDefault(); const form = event.currentTarget; await api("/time-clock/admin/device/register", { method: "POST", body: JSON.stringify({ name: form.elements.name.value }) }); form.reset(); await load(); message("This device is registered."); }
async function deactivateDevice(id) { await api("/time-clock/admin/device/deactivate", { method: "POST", body: JSON.stringify({ id }) }); await load(); message("Device deactivated."); }
function editEntry(id) { const entry = state.admin.entries.find((item) => item.id === id); if (!entry) return; const form = $("#entryForm"); form.elements.id.value = entry.id; form.elements.employeeId.value = entry.employeeId; form.elements.clockIn.value = localInput(entry.clockIn); form.elements.clockOut.value = entry.clockOut ? localInput(entry.clockOut) : ""; form.scrollIntoView({ behavior: "smooth" }); }
function renderAudit(target, items) { target.innerHTML = items.length ? items.slice(0, 100).map((item) => `<article class="audit-item"><div><strong>${esc(item.title)}</strong><span>${esc(item.detail)}</span></div><time>${dt(item.date)}</time></article>`).join("") : "<p>No records yet.</p>"; }
function hours(entry) { return entry.clockOut ? ((new Date(entry.clockOut) - new Date(entry.clockIn)) / 3600000).toFixed(2) : "—"; }
function period(value) { const date = new Date(value), anchor = new Date("2024-01-01T00:00:00"), days = Math.floor((date - anchor) / 86400000), start = new Date(anchor); start.setDate(start.getDate() + Math.floor(days / 14) * 14); const end = new Date(start); end.setDate(end.getDate() + 13); return `${start.toLocaleDateString()} – ${end.toLocaleDateString()}`; }
function localInput(value) { const date = new Date(value), offset = date.getTimezoneOffset(); return new Date(date - offset * 60000).toISOString().slice(0, 16); }
function empty(columns, value) { return `<tr><td colspan="${columns}">${esc(value)}</td></tr>`; }

$("#clockInButton").addEventListener("click", () => clock("in").catch((error) => message(error.message)));
$("#clockOutButton").addEventListener("click", () => clock("out").catch((error) => message(error.message)));
$("#employeeForm").addEventListener("submit", (event) => saveUser(event).catch((error) => message(error.message)));
$("#employeeForm").elements.role.addEventListener("change", toggleEmployeeFields);
$("#cancelEmployee").addEventListener("click", clearEmployeeForm);
$("#entryForm").addEventListener("submit", (event) => saveEntry(event).catch((error) => message(error.message)));
$("#cancelEntry").addEventListener("click", () => $("#entryForm").reset());
$("#deviceForm").addEventListener("submit", (event) => registerDevice(event).catch((error) => message(error.message)));
$("#markPaid").addEventListener("click", () => markPaid().catch((error) => message(error.message)));
$("#refresh").addEventListener("click", () => load().catch((error) => message(error.message)));
document.body.addEventListener("click", (event) => { const target = event.target.closest("button"); if (!target) return; if (target.dataset.editUser) editUser(target.dataset.editUser); if (target.dataset.resetUser) editUser(target.dataset.resetUser, true); if (target.dataset.userStatus) changeStatus(target.dataset.userId, target.dataset.userStatus).catch((error) => message(error.message)); if (target.dataset.editEntry) editEntry(target.dataset.editEntry); if (target.dataset.disableDevice) deactivateDevice(target.dataset.disableDevice).catch((error) => message(error.message)); });
toggleEmployeeFields();
load().catch((error) => message(error.message));
